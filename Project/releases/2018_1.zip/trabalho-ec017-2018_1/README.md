# trabalho-ec017

## Informações gerais
- 5 grupos de 4 integrantes
- Data de entrega por e-mail: 29/junho/18 23h59
- Data da apresentação: 30/junho/18 08h00
- Cada grupo terá 20 minutos para apresentar e 10 minutos de discussão/questionamentos

## Conjuntos de dados disponíveis

- [datasets/breast-cancer.arff](https://archive.ics.uci.edu/ml/datasets/Breast+Cancer)
- [datasets/glass.arff](https://archive.ics.uci.edu/ml/datasets/Glass+Identification)
- [datasets/hepatitis.arff](https://archive.ics.uci.edu/ml/datasets/Hepatitis)
- [datasets/mushroom.arff](https://archive.ics.uci.edu/ml/datasets/Mushroom)
- [datasets/zoo.arff](https://archive.ics.uci.edu/ml/datasets/Zoo)

## Classificadores disponíveis

- [weka.classifiers.bayes.NaiveBayes](http://weka.sourceforge.net/doc.dev/weka/classifiers/bayes/NaiveBayes.html)
- [weka.classifiers.functions.SimpleLogistic](http://weka.sourceforge.net/doc.dev/weka/classifiers/functions/SimpleLogistic.html)
- [weka.classifiers.lazy.KStar](http://weka.sourceforge.net/doc.dev/weka/classifiers/lazy/KStar.html)
- [weka.classifiers.rules.DecisionTable](http://weka.sourceforge.net/doc.stable/weka/classifiers/rules/DecisionTable.html)
- [weka.classifiers.trees.REPTree](http://weka.sourceforge.net/doc.dev/weka/classifiers/trees/REPTree.html)

## Referências

- [references/NaiveBayes.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/NaiveBayes.pdf): LEUNG, K. Ming. Naive bayesian classifier. Polytechnic University Department of Computer Science/Finance and Risk Engineering, 2007.
- [references/SimpleLogistic.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/SimpleLogistic.pdf): SUMNER, Marc; FRANK, Eibe; HALL, Mark. Speeding up logistic model tree induction. In: European Conference on Principles of Data Mining and Knowledge Discovery. Springer, Berlin, Heidelberg, 2005. p. 675-683.
- [references/KStar.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/KStar.pdf): CLEARY, John G.; TRIGG, Leonard E. K*: An instance-based learner using an entropic distance measure. In: Machine Learning Proceedings 1995. 1995. p. 108-114.
- [references/DecisionTable.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/DecisionTable.pdf): KOHAVI, Ron. The power of decision tables. In: European conference on machine learning. Springer, Berlin, Heidelberg, 1995. p. 174-189.
- [references/REPTree.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/REPTree.pdf): BRUNK, Clifford A.; PAZZANI, Michael J. An investigation of noise-tolerant relational concept learning algorithms. In: Machine Learning Proceedings 1991. 1991. p. 389-393.

## Procedimento

1. Clonagem (ou download) deste repositório: https://github.com/marcelovca90/trabalho-ec017

2. Download do Weka: https://www.cs.waikato.ac.nz/~ml/weka/downloading.html. Observação: baixar a "Stable version" (weka-3-8-2)

3. Carregar o conjunto de dados: Explorer > Aba "Preprocess" > Open file... > data_set.arff

4. Balancear o conjunto de dados: Explorer > Aba "Preprocess" > Filter > Choose > weka.filters.supervised.instance.ClassBalancer > Apply

5. Escolher o classificador: Explorer > Aba "Classify" > Classifier > Choose > "classificador"

6. Configurar o classificador: Explorer > Aba "Classify" > clicar na caixa de texto ao lado do botão "Choose"

7. Executar o classificador: Explorer > Aba "Classify" > Test options > Percentage split % > 50 > Start

Os resultados serão exibidos na área de texto "Classifier output". Exemplo:

```
Correctly Classified Instances          37               74      %
Incorrectly Classified Instances        13               26      %
```

Neste caso, o modelo de aprendizado de máquina obteve 74% de acerto no conjunto de testes.

Observação: resultados de execuções passadas podem ser encontrados em "Result list" (sudoeste da tela).

## Apresentação

- Breve revisão sobre o conjunto de dados
  - Descrição do conjunto (do que se trata)
  - Quantidade de instâncias (amostras)
  - Quantidade e descrição dos atributos

- Breve revisão sobre o modelo escolhido
  - Princípio de funcionamento
  - Significado dos parâmetros de configuração

- Simulação
  - Executar 10 experimentos (variando um parâmetro)
    - Se só houver parâmetros booleanos, então fazer a combinação de dois ou mais parâmetros, se possível
    - Se nenhum parâmetro puder ser alterado, então variar o percentual de treinamento/teste
  - Guardar os resultados de cada execução
  - Exibir gráfico "parâmetro versus taxa de acerto"

- Discussão dos resultados

- Conclusão

## Grupos

| Número        | Integrantes                        | Conjunto de dados | Classificador  | Entrega  |
|:-------------:|:----------------------------------:|:-----------------:|:--------------:|:--------:|
| 1             | Felipe, Lara, Patrícia, Rodrigo L. | zoo               | DecisionTable  | ✔️       |
| 2             | Arnaldo, Daniel, Evaldo, Luiz      | hepatitis         | KStar          | ✔️       |
| 3             | Carlos, Lucas, Ranulfo, Rodrigo H. | glass             | REPTree        | ✔️       |
| 4             | Alexsander, João, Jonathan, Vítor  | mushroom          | SimpleLogistic | ✔️       |
| 5             | Dymas, Samir, Saturnino            | breast-cancer     | NaiveBayes     | ✔️       |
