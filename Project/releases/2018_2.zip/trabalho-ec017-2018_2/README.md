# trabalho-ec017

## Informações gerais
- 10 grupos de 5 integrantes
- Data de entrega por e-mail: 23/novembro/18 23h59
- Data da apresentação: 24/novembro/18 10h00
- Cada grupo terá 10 minutos para apresentar e discutir os resultados

## Conjuntos de dados disponíveis

- [datasets/breast-cancer.arff](https://archive.ics.uci.edu/ml/datasets/Breast+Cancer)
- [datasets/colic.arff](https://archive.ics.uci.edu/ml/datasets/Horse+Colic)
- [datasets/credit-g.arff](https://archive.ics.uci.edu/ml/datasets/statlog+(german+credit+data))
- [datasets/diabetes.arff](https://www.kaggle.com/uciml/pima-indians-diabetes-database)
- [datasets/heart-statlog.arff](http://archive.ics.uci.edu/ml/datasets/statlog+(heart))
- [datasets/hepatitis.arff](https://archive.ics.uci.edu/ml/datasets/Hepatitis)
- [datasets/ionosphere.arff](https://archive.ics.uci.edu/ml/datasets/ionosphere)
- [datasets/labor.arff](https://archive.ics.uci.edu/ml/datasets/Labor+Relations)
- [datasets/sonar.arff](http://archive.ics.uci.edu/ml/datasets/connectionist+bench+(sonar,+mines+vs.+rocks))
- [datasets/vote.arff](https://archive.ics.uci.edu/ml/datasets/congressional+voting+records)

## Classificadores disponíveis
- [weka.classifiers.bayes.BayesNet](http://weka.sourceforge.net/doc.dev/weka/classifiers/bayes/BayesNet.html)
- [weka.classifiers.bayes.NaiveBayes](http://weka.sourceforge.net/doc.dev/weka/classifiers/bayes/NaiveBayes.html)
- [weka.classifiers.functions.SimpleLogistic](http://weka.sourceforge.net/doc.dev/weka/classifiers/functions/SimpleLogistic.html)
- [weka.classifiers.functions.VotedPerceptron](http://weka.sourceforge.net/doc.dev/weka/classifiers/functions/VotedPerceptron.html)
- [weka.classifiers.lazy.IBk](http://weka.sourceforge.net/doc.dev/weka/classifiers/lazy/IBk.html)
- [weka.classifiers.lazy.KStar](http://weka.sourceforge.net/doc.dev/weka/classifiers/lazy/KStar.html)
- [weka.classifiers.rules.DecisionTable](http://weka.sourceforge.net/doc.stable/weka/classifiers/rules/DecisionTable.html)
- [weka.classifiers.rules.PART](http://weka.sourceforge.net/doc.dev/weka/classifiers/rules/PART.html)
- [weka.classifiers.trees.RandomTree](http://weka.sourceforge.net/doc.dev/weka/classifiers/trees/RandomTree.html)
- [weka.classifiers.trees.REPTree](http://weka.sourceforge.net/doc.dev/weka/classifiers/trees/REPTree.html)

## Referências

- [references/BayesNet.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/BayesNet.pdf): FRIEDMAN, Nir; GEIGER, Dan; GOLDSZMIDT, Moises. Bayesian network classifiers. Machine learning, v. 29, n. 2-3, p. 131-163, 1997.
- [references/NaiveBayes.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/NaiveBayes.pdf): LEUNG, K. Ming. Naive bayesian classifier. Polytechnic University Department of Computer Science/Finance and Risk Engineering, 2007.
- [references/SimpleLogistic.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/SimpleLogistic.pdf): SUMNER, Marc; FRANK, Eibe; HALL, Mark. Speeding up logistic model tree induction. In: European Conference on Principles of Data Mining and Knowledge Discovery. Springer, Berlin, Heidelberg, 2005. p. 675-683.
- [references/VotedPerceptron.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/VotedPerceptron.pdf): FREUND, Yoav; SCHAPIRE, Robert E. Large margin classification using the perceptron algorithm. Machine learning, v. 37, n. 3, p. 277-296, 1999.
- [references/IBk.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/IBk.pdf): AHA, David W.; KIBLER, Dennis; ALBERT, Marc K. Instance-based learning algorithms. Machine learning, v. 6, n. 1, p. 37-66, 1991.
- [references/KStar.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/KStar.pdf): CLEARY, John G.; TRIGG, Leonard E. K*: An instance-based learner using an entropic distance measure. In: Machine Learning Proceedings 1995. 1995. p. 108-114.
- [references/DecisionTable.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/DecisionTable.pdf): KOHAVI, Ron. The power of decision tables. In: European conference on machine learning. Springer, Berlin, Heidelberg, 1995. p. 174-189.
- [references/PART.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/PART.pdf): FRANK, Eibe; WITTEN, Ian H. Generating accurate rule sets without global optimization. 1998.
- [references/RandomTree.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/RandomTree.pdf): LI, Xinwei. Random Decision Trees. 2004.
- [references/REPTree.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/REPTree.pdf): BRUNK, Clifford A.; PAZZANI, Michael J. An investigation of noise-tolerant relational concept learning algorithms. In: Machine Learning Proceedings 1991. 1991. p. 389-393.

## Procedimento

1. Clonagem (ou download) deste repositório: https://github.com/marcelovca90/trabalho-ec017

2. Download do Weka: https://www.cs.waikato.ac.nz/~ml/weka/downloading.html. Observação: baixar a "Stable version" (weka-3-8-3)

3. Carregar o conjunto de dados: Explorer > Aba "Preprocess" > Open file... > data_set.arff

4. Balancear o conjunto de dados: Explorer > Aba "Preprocess" > Filter > Choose > weka.filters.supervised.instance.ClassBalancer > Apply

5. Escolher o classificador: Explorer > Aba "Classify" > Classifier > Choose > "classificador"

6. Configurar o classificador: Explorer > Aba "Classify" > clicar na caixa de texto ao lado do botão "Choose"

7. Executar o classificador: Explorer > Aba "Classify" > Test options > Percentage split % > 50 > Start

Os resultados serão exibidos na área de texto "Classifier output". Exemplo:

```
Correctly Classified Instances          37               74      %
Incorrectly Classified Instances        13               26      %
```

Neste caso, o modelo de aprendizado de máquina obteve 74% de acerto no conjunto de testes.

Observação: resultados de execuções passadas podem ser encontrados em "Result list" (sudoeste da tela).

## Apresentação

- Breve revisão sobre o conjunto de dados
  - Descrição do conjunto (do que se trata)
  - Quantidade de instâncias (amostras)
  - Quantidade e descrição dos atributos

- Breve revisão sobre o modelo escolhido
  - Princípio de funcionamento
  - Significado dos parâmetros de configuração

- Simulação
  - Executar 10 experimentos (variando um parâmetro)
    - Se só houver parâmetros booleanos, então fazer a combinação de dois ou mais parâmetros, se possível
    - Se nenhum parâmetro puder ser alterado, então variar o percentual de treinamento/teste
  - Guardar os resultados de cada execução
  - Exibir gráfico "parâmetro versus taxa de acerto"

- Discussão dos resultados

- Conclusão

## Grupos

| Número        | Integrantes                                       | Conjunto de dados | Classificador   | Entrega  |
|:-------------:|:-------------------------------------------------:|:-----------------:|:---------------:|:--------:|
| 1             | Fernanda, Lucas G., Karla, João P., Daniel        | heart-statlog     | BayesNet        |          |
| 2             | Lucas S., Pablo, Pedro Z., Alexandre, Tiago P.    | labor             | NaiveBayes      | ✔️        |
| 3             | João G., Karina, Mateus P., Luiz G.               | diabetes          | SimpleLogistic  |          |
| 4             | Guilherme, Gustavo C., Danilo F., Mariana         | vote              | VotedPerceptron | ✔️        |
| 5             | Bianca, Nathália, Gustavo P., Luísa               | hepatitis         | IBk             | ✔️        |
| 6             | Matheus C., Pedro M., Lucas V., Luiz F., Leonardo | breast-cancer     | KStar           | ✔️        |
| 7             | André R., Jonathan, Nicholas, Arthur              | sonar             | DecisionTable   |          |
| 8             | Marina, Maria Isabel, André, Iury, Samuel         | colic             | PART            | ✔️        |
| 9             | Laura, Jéssica, Alan, Thiago M., Rafael           | credit-g          | RandomTree      | ✔️        |
| 10            | Wesley, William, Isabela, Carlos E., Henrique     | ionosphere        | REPTree         | ✔️        |
