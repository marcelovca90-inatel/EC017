# trabalho-ec017

## Informações gerais
- 6 grupos de 3 ou 4 integrantes
- Data de entrega por e-mail: 28/junho/19 23h59
- Data da apresentação: 29/junho/19 08h00
- Cada grupo terá 20 minutos para apresentar e discutir os resultados

## Conjuntos de dados disponíveis

- [datasets/diabetes.arff](https://www.kaggle.com/uciml/pima-indians-diabetes-database)
- [datasets/heart-statlog.arff](http://archive.ics.uci.edu/ml/datasets/statlog+(heart))
- [datasets/colic.arff](https://archive.ics.uci.edu/ml/datasets/Horse+Colic)
- [datasets/vote.arff](https://archive.ics.uci.edu/ml/datasets/congressional+voting+records)
- [datasets/ionosphere.arff](https://archive.ics.uci.edu/ml/datasets/ionosphere)
- [datasets/breast-cancer.arff](https://archive.ics.uci.edu/ml/datasets/Breast+Cancer)

## Classificadores disponíveis
- [weka.classifiers.lazy.KStar](http://weka.sourceforge.net/doc.dev/weka/classifiers/lazy/KStar.html)
- [weka.classifiers.trees.REPTree](http://weka.sourceforge.net/doc.dev/weka/classifiers/trees/REPTree.html)
- [weka.classifiers.functions.SimpleLogistic](http://weka.sourceforge.net/doc.dev/weka/classifiers/functions/SimpleLogistic.html)
- [weka.classifiers.rules.PART](http://weka.sourceforge.net/doc.dev/weka/classifiers/rules/PART.html)
- [weka.classifiers.bayes.BayesNet](http://weka.sourceforge.net/doc.dev/weka/classifiers/bayes/BayesNet.html)
- [weka.classifiers.functions.VotedPerceptron](http://weka.sourceforge.net/doc.dev/weka/classifiers/functions/VotedPerceptron.html)

## Referências

- [references/KStar.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/KStar.pdf): CLEARY, John G.; TRIGG, Leonard E. K*: An instance-based learner using an entropic distance measure. In: Machine Learning Proceedings 1995. 1995. p. 108-114.
- [references/REPTree.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/REPTree.pdf): BRUNK, Clifford A.; PAZZANI, Michael J. An investigation of noise-tolerant relational concept learning algorithms. In: Machine Learning Proceedings 1991. 1991. p. 389-393.
- [references/SimpleLogistic.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/SimpleLogistic.pdf): SUMNER, Marc; FRANK, Eibe; HALL, Mark. Speeding up logistic model tree induction. In: European Conference on Principles of Data Mining and Knowledge Discovery. Springer, Berlin, Heidelberg, 2005. p. 675-683.
- [references/PART.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/PART.pdf): FRANK, Eibe; WITTEN, Ian H. Generating accurate rule sets without global optimization. 1998.
- [references/BayesNet.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/BayesNet.pdf): FRIEDMAN, Nir; GEIGER, Dan; GOLDSZMIDT, Moises. Bayesian network classifiers. Machine learning, v. 29, n. 2-3, p. 131-163, 1997.
- [references/VotedPerceptron.pdf](https://github.com/marcelovca90/trabalho-ec017/raw/master/references/VotedPerceptron.pdf): FREUND, Yoav; SCHAPIRE, Robert E. Large margin classification using the perceptron algorithm. Machine learning, v. 37, n. 3, p. 277-296, 1999.

## Procedimento

1. Clonagem (ou download) deste repositório: https://github.com/marcelovca90/trabalho-ec017

2. Download do Weka: https://www.cs.waikato.ac.nz/~ml/weka/downloading.html. Observação: baixar a "Stable version" (weka-3-8-3)

3. Carregar o conjunto de dados: Explorer > Aba "Preprocess" > Open file... > data_set.arff

4. Balancear o conjunto de dados: Explorer > Aba "Preprocess" > Filter > Choose > weka.filters.supervised.instance.ClassBalancer > Apply

5. Escolher o classificador: Explorer > Aba "Classify" > Classifier > Choose > "classificador"

6. Configurar o classificador: Explorer > Aba "Classify" > clicar na caixa de texto ao lado do botão "Choose"

7. Executar o classificador: Explorer > Aba "Classify" > Test options > Percentage split % > 50 > Start

Os resultados serão exibidos na área de texto "Classifier output". Exemplo:

```
Correctly Classified Instances          37               74      %
Incorrectly Classified Instances        13               26      %
```

Neste caso, o modelo de aprendizado de máquina obteve 74% de acerto no conjunto de testes.

Observação: resultados de execuções passadas podem ser encontrados em "Result list" (sudoeste da tela).

## Apresentação

- Breve revisão sobre o conjunto de dados
  - Descrição do conjunto (do que se trata)
  - Quantidade de instâncias (amostras)
  - Quantidade e descrição dos atributos

- Breve revisão sobre o modelo escolhido
  - Princípio de funcionamento
  - Significado dos parâmetros de configuração

- Simulação
  - Executar 10 experimentos (variando um parâmetro)
    - Se só houver parâmetros booleanos, então fazer a combinação de dois ou mais parâmetros, se possível
    - Se nenhum parâmetro puder ser alterado, então variar o percentual de treinamento/teste
  - Guardar os resultados de cada execução
  - Exibir gráfico "parâmetro versus taxa de acerto"

- Discussão dos resultados

- Conclusão

## Grupos

| Número        | Integrantes                                                                                                                           | Conjunto de dados  | Classificador   | Entrega  |
|:-------------:|:-------------------------------------------------------------------------------------------------------------------------------------:|:------------------:|:---------------:|:--------:|
| 1             | Carlos Henrique Jacinto<br>Daniel Liz Fonseca Castro Borges<br>Eduardo Henrique de Freitas Rotundaro<br>Pedro Henrique Carvalho Alves | diabetes           | KStar           |    ✔️     |
| 2             | Márcio Silva Rotella<br>Eduardo de Souza Lima Padinha<br>Rodrigo Rufino Ribeiro                                                       | heart-statlog      | REPTree         |    ✔️     |
| 3             | Giovanni Pimenta Ribeiro Araujo<br>Lucas Riboli Freire<br>Pedro Henrique Polez Rocha                                                  | colic              | SimpleLogistic  |    ✔️     |
| 4             | Danilo Germiniani Virgínio<br>João Guilherme Lima do Couto<br>Walace Santos Barbosa                                                   | vote               | PART            |    ✔️     |
| 5             | Charles David Mártir Machado<br>Leonardo Costa Damasceno<br>Leonardo Vidal Prado Maciel                                               | ionosphere         | BayesNet        |    ✔️     |
| 6             | Lucas Riêra Abbade<br>Luiz Felipe Pereira Lima<br>Pedro Carletti Soares                                                               | breast-cancer      | VotedPerceptron |    ✔️     |
